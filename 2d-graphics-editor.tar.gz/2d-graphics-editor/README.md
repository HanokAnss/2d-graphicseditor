# 2D Graphics Editor

A text-based 2D graphics editor that draws shapes using `*` and `_` characters on an 80×24 character canvas.

## Features

- Draw **lines** (Bresenham's algorithm)
- Draw **rectangles**
- Draw **circles** (Midpoint algorithm)
- Draw **triangles**
- **Add**, **delete**, and **modify** objects
- All objects are stored in a list and redrawn on demand

## Build

```bash
make
```

## Run

```bash
./editor
```

## Example session

```
Choice: 1          (add line)
Line r1 c1 r2 c2: 2 5 10 40

Choice: 3          (add circle)
Circle center row col, radius: 10 40 6

Choice: 8          (display canvas)
```

## File structure

| File | Purpose |
|------|---------|
| `canvas.c / .h` | 2D `char` array and `display()` |
| `shapes.c / .h` | `draw_line`, `draw_rectangle`, `draw_circle`, `draw_triangle` |
| `objects.c / .h` | Object list – add, delete, modify, redraw |
| `main.c` | Menu-driven entry point |
| `Makefile` | Build rules |

## Daily push reminder

```bash
git add .
git commit -m "Day N: what I did today"
git push
```
